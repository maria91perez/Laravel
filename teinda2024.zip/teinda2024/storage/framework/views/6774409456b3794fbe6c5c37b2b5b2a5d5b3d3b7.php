

<?php $__env->startSection('titulo', 'Listado de Facturas'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container text-center">
    <h1>Listado de Facturas</h1>
    <?php echo Form::open(['route' => 'facturas.index', 'method' => 'GET', 'class' => 'navbar-form']); ?>

    <div class="form-group">
        <?php echo Form::text('numero', null, ['class' => 'form-control', 'id' => 'numero', 'placeholder' => 'Buscar Facturas']); ?>

        <br>
        <?php echo Form::submit('Buscar Factura', ['class' => 'btn btn-primary']); ?>

        <a href="<?php echo e(route('facturas.index')); ?>" class="btn btn-primary">Mostrar Facturas</a>
    </div>
    <br>
<?php echo Form::close(); ?>




    
    
    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#crearClienteModal">
        Crear Nueva Factura
    </button>
    
    <div class="modal fade" id="crearClienteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Crear Factura</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Aquí sSe carga la vista crear.blade.php -->
                    <?php echo Form::open(['route' => 'facturas.store', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo Form::label('numero', 'Número de la factura:'); ?>

            <?php echo Form::text('numero', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Número de la factura...']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('valor', 'Valor de la factura:'); ?>

            <?php echo Form::text('valor', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Valor de la factura...']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('detalles', 'Detalles de la factura:'); ?>

                <?php echo Form::textarea('detalles', null, ['id' => 'editor', 'class' => 'form-control ckeditor', 'placeholder' => 'Detalles de la factura...']); ?>

<script>
    CKEDITOR.replace('editor');
</script>


        </div>
        <div class="form-group">
         <?php echo Form::label('idcliente', 'Clientes:'); ?>

           <?php echo Form::select('idcliente', $clientes, null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('idforma', 'Formas de Pago:'); ?>

            <?php echo Form::select('idforma', $formas, null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('idestado', 'Estados:'); ?>

            <?php echo Form::select('idestado', $estados, null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('archivo', 'Archivo:'); ?>

            <?php echo Form::file('archivo', ['class' => 'form-control']); ?>

        </div>

        <?php echo Form::submit('Guardar Factura', ['class' => 'btn btn-success']); ?>

    <?php echo Form::close(); ?>





        </div>
            </div>
        </div>
    </div>
    <table class="table table-striped table-bordered table-hover table-success">
    <br>
        <thead>
            <tr>
                <th>Actualizar</th>
                <th>Eliminar</th>
                <th>Número</th>
                <th >Cliente</th>
                <th>RFC</th>

                <th>Valor</th>
                <th>Archivo</th>
                <th>Detalles</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                    <td>
                        <!-- Botón para abrir el modal de edición de cliente -->
                        <a class="bi bi-pencil-square btn btn-primary" data-bs-toggle="modal" data-bs-target="#editarClienteModal<?php echo e($factura->id); ?>"></a>
                        

                        <!-- Modal para editar un cliente -->
                        <div class="modal fade" id="editarClienteModal<?php echo e($factura->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Editar Factura</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <!-- Incluir el formulario de edición de cliente aquí -->
                                        <?php echo Form::model($factura, ['route' => ['facturas.update', $factura->id], 'method' => 'PUT', 'files' => true]); ?>

            <div class="form-group">
                <?php echo Form::label('numero', 'Número de factura'); ?>

                <?php echo Form::text('numero', null, ['class'=>'form-control', 'required'=>'required', 'placeholder'=>'Número de factura...']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('valor', 'Valor'); ?>

                <?php echo Form::text('valor', null, ['class'=>'form-control', 'required'=>'required', 'placeholder'=>'Valor de la factura...']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('detalles', 'Detalles'); ?>

                
                <?php echo Form::textarea('detalles', null, ['id' => 'editor', 'class' => 'form-control ckeditor', 'placeholder' => 'Detalles de la factura...']); ?>

            </div>
            <div class="form-group">
         <?php echo Form::label('idcliente', 'Clientes:'); ?>

           <?php echo Form::select('idcliente', $clientes, null, ['class' => 'form-control ']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('idforma', 'Formas de Pago:'); ?>

            <?php echo Form::select('idforma', $formas, null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('idestado', 'Estados:'); ?>

            <?php echo Form::select('idestado', $estados, null, ['class' => 'form-control']); ?>

        </div>
            <div class="form-group">
                <?php echo Form::label('archivo', 'Archivo'); ?>

                <?php echo Form::file('archivo', ['class'=>'form-control', 'placeholder'=>'archivo']); ?>

            </div>
            <br>
            <?php echo Form::submit('Guardar Factura', ['class'=>'btn btn-success']); ?>

        <?php echo Form::close(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <!-- Formulario para eliminar un cliente -->
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#eliminarClienteModal<?php echo e($factura->id); ?>">
    <i class="bi bi-trash"></i>
</button>

<!-- Modal para confirmar eliminación del cliente -->
<div class="modal fade" id="eliminarClienteModal<?php echo e($factura->id); ?>" tabindex="-1" aria-labelledby="eliminarClienteModalLabel<?php echo e($factura->id); ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="eliminarClienteModalLabel<?php echo e($factura->id); ?>">Eliminar Cliente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-white">
    ¿Estás seguro de que deseas eliminar este cliente?
        </div>

            <div class="modal-footer">
                <!-- Formulario para eliminar cliente -->
                <?php echo Form::open(['route' => ['facturas.destroy', $factura->id], 'method' => 'DELETE']); ?>

                    <button type="submit" class="btn btn-danger">Eliminar</button>
                <?php echo Form::close(); ?>

                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>
                    </td>
                    <td><?php echo e($factura->numero); ?></td>
                <td><?php echo e($factura->cliente->nombre); ?></td>
                <td><?php echo e($factura->cliente->rfc); ?></td>
                <td>$<?php echo e(number_format($factura->valor)); ?></td>
                
                <td><img class="imagen-factura" src="<?php echo e(asset('archivos/' . $factura->archivo)); ?>"></td>

                <td><?php echo $factura->detalles; ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($facturas->links()); ?>     
    <br>
   
    
</div>
<?php $__env->stopSection(); ?>



<style>
.imagen-factura {
    max-width: 85px;
    height: auto; /* Esto mantendrá la proporción de la imagen */
}
</style>
<style>
    label {
    color: #ffffff; /* Color blanco */
}
</style>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\Apache24\htdocs\TiendaCrudFebJul24-master\resources\views/facturas/index.blade.php ENDPATH**/ ?>