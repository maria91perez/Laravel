<footer style="background-color: #BD66E5 ; color: ; text-align: center; padding: 10px 0;">
    <p>© 2024 Lorena. Todos los derechos reservados.</p>
</footer>
<?php /**PATH C:\www\Apache24\htdocs\TiendaCrudFebJul24-master\resources\views/secciones/footer.blade.php ENDPATH**/ ?>