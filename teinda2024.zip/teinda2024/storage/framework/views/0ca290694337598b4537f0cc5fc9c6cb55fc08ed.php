 </div>
<?php $__env->stopSection(); ?>

<style>
p.fant {font-family: fantasy;}

</style><?php /**PATH C:\www\Apache24\htdocs\TiendaCrudFebJul24-master\resources\views/index.blade.php ENDPATH**/ ?>