<!-- Formulario de edición del cliente -->
<?php echo Form::model($perfil, ['route' => ['perfiles.update', $perfil->id], 'method' => 'PUT']); ?>

    <div class="form-group">
        <?php echo Form::label('nombre', 'Nombre del perfil', ['class' => 'titulo-blanco']); ?>

        <?php echo Form::text('nombre', null, ['class' => 'form-control', 'placeholder' => 'Nombre del perfil...']); ?>

    </div>
    
    <?php echo Form::submit('Guardar Perfil', ['class' => 'btn btn-primary']); ?>

<?php echo Form::close(); ?>

<!-- Modal para editar cliente -->
<div class="modal fade" id="editarModal" tabindex="-1" role="dialog" aria-labelledby="editarModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editarModalLabel">Editar Cliente</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Formulario de edición del cliente -->
                <form action="<?php echo e(route('perfiles.update', $perfil->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre del Cliente</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e($perfil->nombre); ?>" required>
                    </div>
                              <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                </form>
            </div>
        </div>
    </div>
</div>
<style>
    .titulo-blanco {
    color: #ffffff; /* Color blanco */
}
</style><?php /**PATH C:\www\Apache24\htdocs\teinda2024\resources\views/perfiles/editar.blade.php ENDPATH**/ ?>