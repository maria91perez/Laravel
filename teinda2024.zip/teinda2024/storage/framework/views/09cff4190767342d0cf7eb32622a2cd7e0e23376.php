
                <form action="<?php echo e(route('clientes.update', $cliente->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre del Cliente</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e($cliente->nombre); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="rfc" class="form-label">RFC del Cliente</label>
                        <input type="text" class="form-control" id="rfc" name="rfc" value="<?php echo e($cliente->rfc); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="direccion" class="form-label">Dirección del Cliente</label>
                        <input type="text" class="form-control" id="direccion" name="direccion" value="<?php echo e($cliente->direccion); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="telefono" class="form-label">Teléfono del Cliente</label>
                        <input type="text" class="form-control" id="telefono" name="telefono" value="<?php echo e($cliente->telefono); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email del Cliente</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($cliente->email); ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                </form>
            
<style>
    label {
    color: #ffffff; /* Color blanco */
}
</style><?php /**PATH C:\www\Apache24\htdocs\teinda2024\resources\views/clientes/editar.blade.php ENDPATH**/ ?>