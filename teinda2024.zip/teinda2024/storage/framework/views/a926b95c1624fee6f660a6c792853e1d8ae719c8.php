<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"
  button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span><img src="/img/carrito.png" width="80"alt="" > MI TIENDA</a>
    <link rel="stylesheet" href="../css/estilo.css" >

   
    </button>
    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav me-auto">
        <?php if(auth()->guard()->guest()): ?>
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(route('login')); ?>">Acceso</a>
        </li>
        <li class="nav-item">
          &nbsp;
        </li>
        <li class="nav-item">
          <a href="<?php echo e(route('register')); ?>">Registro</a>
        </li>
        <?php else: ?>
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(route('perfiles.index')); ?>">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="<?php echo e(route('perfiles.index')); ?>">Perfiles</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('clientes.index')); ?>">Clientes</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('facturas.index')); ?>">Facturacion</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Productos</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Pedidos</a>
        </li>
        <li class="dropdown">
          <a href="#" class="nav-link" data-toggle="dropdown" role="button" aria-expanded="false">
            User conectado: <?php echo e(Auth::user()->name); ?>

          </a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="#" data-toggle="modal" data-target="#mzodal-usuario">Mis datos</a></li>
            <li>
              <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                Cerrar sesion
              </a>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

              </form>
            </li>
          </ul>
          
        </li>
        <li class="dropdown">
        </li>
        <?php endif; ?>
      </ul>
      
    </div>
  </div>
</nav>
<?php /**PATH C:\www\Apache24\htdocs\teinda2024\resources\views/secciones/menu.blade.php ENDPATH**/ ?>