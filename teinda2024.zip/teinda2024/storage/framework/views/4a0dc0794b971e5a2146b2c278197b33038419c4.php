<form action="<?php echo e(route('perfiles.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="nombre" class="form-label">Nombre del Perfil</label>
        <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre del Perfil" required>
    </div>
    <button type="submit" class="btn btn-primary">Guardar Perfil</button>
</form><?php /**PATH C:\www\Apache24\htdocs\TiendaCrudFebJul24-master\resources\views/perfiles/crear.blade.php ENDPATH**/ ?>