
<?php $__env->startSection('titulo', 'Bienvenidos'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php echo $__env->make('secciones.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\Apache24\htdocs\teinda2024\resources\views/index.blade.php ENDPATH**/ ?>