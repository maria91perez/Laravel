<nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
  <div class="container-fluid">
    <img src="images/logo.png" width="70" alt="Logo" class="navbar-brand">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
        <a class="nav-link active" href="<?php echo e(route('index')); ?>">Home
      <span class="visually-hidden">(current)</span>
        </a>
        </li>
        
        <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Dropdown</a>
                  <div class="dropdown-menu">
                            <?php if(Route::has('login')): ?>
                                
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                
                            <?php endif; ?>
                            </div>
</li>
                        <?php else: ?>
                        
        
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(Route('clientes.index')); ?>">Clientes</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="<?php echo e(Route('perfiles.index')); ?>">Perfiles</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(Route('facturas.index')); ?>">Facturacion</a>
        </li>
        
        <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>

                        <?php endif; ?>
      </ul>
      <form class="d-flex">
        <input class="form-control me-sm-2" type="search" placeholder="Search">
        <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
<?php /**PATH C:\xampp\htdocs\TiendaCrudFebJul24-master\resources\views/secciones/menu.blade.php ENDPATH**/ ?>