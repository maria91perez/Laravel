    

    <?php $__env->startSection('titulo', 'Listado de Clientes'); ?>
    <?php $__env->startSection('contenido'); ?>
        <div class="container text-center">
        <h1>Listado de Clientes</h1>
        
        
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#buscarModal">
        Buscar Cliente
    </button>
    <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-primary">Restablecere Clientes</a>
    
    <div class="modal fade" id="buscarModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Buscar</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                <?php echo Form::open(['route' => 'clientes.index', 'method' => 'GET', 'class' => 'navbar-form']); ?>

    <div class="form-group">
        <?php echo Form::text('nombre', null, ['class' => 'form-control', 'id' => 'nombre', 'placeholder' => 'Buscar Cliente']); ?>

        <br>
        <?php echo Form::submit('Buscar Cliente', ['class' => 'btn btn-primary']); ?>

        
    </div>
    <br>
<?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<br>
<br>
<br>


        <!-- Botón para abrir el modal -->
    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#crearClienteModal">
        Crear Nuevo Cliente
    </button>

    <!-- Modal para crear un nuevo cliente -->
    <div class="modal fade" id="crearClienteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Crear Cliente</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Aquí sSe carga la vista crear.blade.php -->
                    <?php echo $__env->make('clientes.crear', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

        <br>
        <table class="table table-striped table-bordered table-hover table-success">
        <br>
        <div class="container">
                <thead>
                    <tr>
                        <th scope="col">Actualizar</th>
                        <th scope="col">Eliminar</th>
                        <th scope="col">Id</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">RFC</th>
                        <th scope="col">Direccion</th>
                        <th scope="col">Telefono</th>
                        <th scope="col">Email</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Aquí deberías agregar tus filas de datos si tienes alguna -->
                </tbody>

                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <!-- Botón para abrir el modal de edición de cliente -->
                        <a class="bi bi-pencil-square btn btn-primary" data-bs-toggle="modal" data-bs-target="#editarClienteModal<?php echo e($cliente->id); ?>"></a>
                        

                        <!-- Modal para editar un cliente -->
                        <div class="modal fade" id="editarClienteModal<?php echo e($cliente->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Editar Cliente</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <!-- Incluir el formulario de edición de cliente aquí -->
                                        <?php echo $__env->make('clientes.editar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <!-- Formulario para eliminar un cliente -->
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#eliminarClienteModal<?php echo e($cliente->id); ?>">
    <i class="bi bi-trash"></i>
</button>

<!-- Modal para confirmar eliminación del cliente -->
<div class="modal fade" id="eliminarClienteModal<?php echo e($cliente->id); ?>" tabindex="-1" aria-labelledby="eliminarClienteModalLabel<?php echo e($cliente->id); ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="eliminarClienteModalLabel<?php echo e($cliente->id); ?>">Eliminar Cliente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-white">
    ¿Estás seguro de que deseas eliminar este cliente?
        </div>

            <div class="modal-footer">
                <!-- Formulario para eliminar cliente -->
                <?php echo Form::open(['route' => ['clientes.destroy', $cliente->id], 'method' => 'DELETE']); ?>

                    <button type="submit" class="btn btn-danger">Eliminar</button>
                <?php echo Form::close(); ?>

                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>


                    
                    <td><?php echo e($cliente->id); ?></td>
                    <td><?php echo e($cliente->nombre); ?></td>
                    <td><?php echo e($cliente->rfc); ?></td>
                    <td><?php echo e($cliente->direccion); ?></td>
                    <td><?php echo e($cliente->telefono); ?></td>
                    <td><?php echo e($cliente->email); ?></td>
                </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                
            </table>
            
        <?php echo e($clientes->links()); ?>            
        </div>
        
    <br>
    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\Apache24\htdocs\TiendaCrudFebJul24-master\resources\views/Clientes/index.blade.php ENDPATH**/ ?>