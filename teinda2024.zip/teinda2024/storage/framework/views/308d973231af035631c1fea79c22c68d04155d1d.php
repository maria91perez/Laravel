<link rel="stylesheet" href="../css/footer.css" >
<link rel="stylesheet" href="../../css/footer.css" >

<footer>
<div class="section">
    <h8>Facebook</h8>
    <p> 
        <a href="https://www.facebook.com/Mar.Del.Ángel "><img src="/img/face.png" alt="Icono Facebook" class="icon" style="width: 30px; height: 30px";>MARIA DEL CARMEN PEREZ DEL ANGEL<H1></H1></a>    
        </p>
    </div>
    <div class="section">
    <h8>Gmail</h8>
        <p>
            <a href="https://mail.google.com/mail/u/0/?tab=rm&ogbl#inbox"><img src="/img/gmail.png" alt="IconoBoostrap" class="icon" style="width: 30px; height: 30px" >mardaperez54@gmail.com</a>
        </p>

    </div>

    <div class="section">
        <h8></h8>
        <br>
        <h6 class="small-text">MARIA DEL CARMEN PEREZ DEL ANGEL</h6>

    </div>
</footer><?php /**PATH C:\www\Apache24\htdocs\teinda2024\resources\views/secciones/footer.blade.php ENDPATH**/ ?>