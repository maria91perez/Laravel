
<?php $__env->startSection('titulo','Editar una factura'); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="container text-center">
        <h1>Editar Factura</h1>
        <br>
        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo Form::model($factura, ['route' => ['facturas.update', $factura->id], 'method' => 'PUT', 'files' => true]); ?>

            <div class="form-group">
                <?php echo Form::label('numero', 'Número de factura'); ?>

                <?php echo Form::text('numero', null, ['class'=>'form-control', 'required'=>'required', 'placeholder'=>'Número de factura...']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('valor', 'Valor'); ?>

                <?php echo Form::text('valor', null, ['class'=>'form-control', 'required'=>'required', 'placeholder'=>'Valor de la factura...']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('detalles', 'Detalles'); ?>

                
                <?php echo Form::textarea('detalles', null, ['id' => 'editor', 'class' => 'form-control ckeditor', 'placeholder' => 'Detalles de la factura...']); ?>

            </div>
            <div class="form-group">
         <?php echo Form::label('idcliente', 'Clientes:'); ?>

           <?php echo Form::select('idcliente', $clientes, null, ['class' => 'form-control ']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('idforma', 'Formas de Pago:'); ?>

            <?php echo Form::select('idforma', $formas, null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('idestado', 'Estados:'); ?>

            <?php echo Form::select('idestado', $estados, null, ['class' => 'form-control']); ?>

        </div>
            <div class="form-group">
                <?php echo Form::label('archivo', 'Archivo'); ?>

                <?php echo Form::file('archivo', ['class'=>'form-control', 'placeholder'=>'archivo']); ?>

            </div>
            <br>
            <?php echo Form::submit('Guardar Factura', ['class'=>'btn btn-success']); ?>

        <?php echo Form::close(); ?>

        <hr>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TiendaCrudFebJul24-master\resources\views/facturas/editar.blade.php ENDPATH**/ ?>