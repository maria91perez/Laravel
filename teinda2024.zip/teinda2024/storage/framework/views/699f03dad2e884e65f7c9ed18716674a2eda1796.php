<footer style="background-color: #333; color: white; text-align: center; padding: 10px 0;">
    <p>© 2024 Edu's Shop. Todos los derechos reservados.</p>
</footer>
<?php /**PATH C:\xampp\htdocs\TiendaCrudFebJul24-master\resources\views/secciones/footer.blade.php ENDPATH**/ ?>