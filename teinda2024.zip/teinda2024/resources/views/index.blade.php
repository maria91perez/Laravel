@extends('master')
@section('titulo', 'Bienvenidos')

@section('contenido')
    @include('secciones.banner')
@endsection